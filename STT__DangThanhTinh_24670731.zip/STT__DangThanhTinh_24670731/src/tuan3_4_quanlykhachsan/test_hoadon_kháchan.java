package tuan3_4_quanlykhachsan;

public class test_hoadon_kháchan {
public static void main(String[] args) {
	
}
}
