package tuan3_4_quanlykhachsan;

import java.time.LocalDate;

public abstract class HoaDon {
private int maHD;
private LocalDate ngayHoaDon;
private int maPhong;
private float donGia;
protected HoaDon(int maHD, LocalDate ngayHoaDon2, int maPhong, float donGia) {
	
	this.maHD = maHD;
	this.ngayHoaDon = ngayHoaDon2;
	this.maPhong = maPhong;
	this.donGia = donGia;
}
public int getMaHD() {
	return maHD;
}
public void setMaHD(int maHD) {
	this.maHD = maHD;
}
public LocalDate getNgayHoaDon() {
	return ngayHoaDon;
}
public void setNgayHoaDon(LocalDate ngayHoaDon) {
	this.ngayHoaDon = ngayHoaDon;
}
public int getMaPhong() {
	return maPhong;
}
public void setMaPhong(int maPhong) {
	this.maPhong = maPhong;
}
public float getDonGia() {
	return donGia;
}
public void setDonGia(float donGia) {
	this.donGia = donGia;
}

@Override
public String toString() {
	return "HoaDon [maHD=" + maHD + ", ngayHoaDon=" + ngayHoaDon + ", maPhong=" + maPhong + ", donGia=" + donGia + "]";
}
public abstract double thanhTien();
}
