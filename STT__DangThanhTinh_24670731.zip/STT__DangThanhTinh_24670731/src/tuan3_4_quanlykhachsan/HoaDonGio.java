package tuan3_4_quanlykhachsan;

import java.time.LocalDate;

public class HoaDonGio extends HoaDon {
	private int soGio;

	protected HoaDonGio(int maHD, LocalDate ngayHoaDon, int maPhong, float donGia, int soGio) {
		super(maHD, ngayHoaDon, maPhong, donGia);
		this.soGio = soGio;
	}

	public int getSoGio() {
		return soGio;
	}

	public void setSoGio(int soGio) {
		if (soGio > 24 && soGio < 30) {
			throw new IllegalArgumentException("Số giờ không hợp lệ: " + soGio);
		}
		this.soGio = soGio;
	}

	@Override
	public double thanhTien() {
		// TODO Auto-generated method stub
		if (this.soGio > 24 && this.soGio < 30) {
			return 24 * this.getDonGia();
		} else if (this.soGio >= 30) {
			return 0;
		}
		return soGio * this.getDonGia();
	}

	@Override
	public String toString() {
		return super.toString() + ", [soGio=" + soGio + ", getSoGio()=" + getSoGio() + ", thanhTien()=" + thanhTien()
				+ "]";
	}

}
