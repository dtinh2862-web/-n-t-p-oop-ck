package tuan3_4_quanlykhachsan;

import java.time.LocalDate;

public class DanhSachHoaDon {

	private HoaDon[] ds;
	private int soLuong;

	public DanhSachHoaDon(int kichThuoc) {
		ds = new HoaDon[kichThuoc];
		soLuong = 0;
	}

	public void nhap(HoaDon hd) {
		if (this.soLuong < ds.length) {
			ds[soLuong] = hd;
			soLuong++;
		} else {
			System.out.println("Danh sách đầy!");
		}
	}

	public void xuat() {
		for (int i = 0; i < this.soLuong; i++) {
			System.out.println(ds[i]);
		}
	}

	public int tongHoaDonGio() {
		int dem = 0;
		for (int i = 0; i < soLuong; i++) {
			if (ds[i] instanceof HoaDonGio)
				dem++;
		}
		return dem;
	}

	public int tongHoaDonNgay() {
		int dem = 0;
		for (int i = 0; i < this.soLuong; i++) {
			if (ds[i] instanceof HoaDonNgay)
				dem++;

		}
		return dem;
	}

	public double tbTien_9_2013() {
       double tongTien=0;
       int dem=0;
       for(int i=0;i<this.soLuong;i++) {
    	   HoaDon hd=ds[i];
    	   LocalDate ngay=hd.getNgayHoaDon();
    	   if(ngay.getMonthValue()==9 && ngay.getYear()==2013) {
    		   tongTien+=hd.thanhTien();
    		   dem++;
    	   }
    	   
       }
       if(dem==0) {
    	   return 0;
    	   
       }else {
    	   return tongTien/dem;
       }
	}
}
