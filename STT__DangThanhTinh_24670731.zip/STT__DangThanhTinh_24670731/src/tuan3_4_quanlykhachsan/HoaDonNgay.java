package tuan3_4_quanlykhachsan;

import java.time.LocalDate;

public class HoaDonNgay extends HoaDon {
	private int soNgayThue;

	protected HoaDonNgay(int maHD, LocalDate ngayHoaDon, int maPhong, float donGia, int soNgayThue) {
		super(maHD, ngayHoaDon, maPhong, donGia);
		this.soNgayThue = soNgayThue;
	}

	public int getSoNgayThue() {
		return soNgayThue;
	}

	public void setSoNgayThue(int soNgayThue) {
		this.soNgayThue = soNgayThue;
	}

	@Override
	public double thanhTien() {
		// TODO Auto-generated method stub
		if (this.soNgayThue > 7) {
			return (7 * this.getDonGia()) + (this.soNgayThue - 7) * (this.getDonGia() * 0.8);
		} else {
			return this.thanhTien() * this.getDonGia();
		}
	}

	@Override
	public String toString() {
		return super.toString()+"HoaDonNgay [soNgayThue=" + soNgayThue + ", getSoNgayThue()=" + getSoNgayThue() + ", thanhTien()="
				+ thanhTien() + "]";
	}


}
