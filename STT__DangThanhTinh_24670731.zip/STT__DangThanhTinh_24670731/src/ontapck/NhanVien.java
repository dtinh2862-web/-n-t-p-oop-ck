package ontapck;

public abstract class NhanVien {
	private String MaSv;
	private String hoTen;
	private String dt;
	private double luongCb;
	public NhanVien() {
		this.MaSv="";
		this.hoTen="";
		this.dt="";
		this.luongCb=0.0;
	}

	protected NhanVien(String maSv, String hoTen, String dt, double luongCb) {

		MaSv = maSv;
		this.hoTen = hoTen;
		this.dt = dt;
		this.luongCb = luongCb;
	}

	public String getMaSv() {
		return MaSv;
	}

	public void setMaSv(String maSv) {
		MaSv = maSv;
	}

	public String getHoTen() {
		return hoTen;
	}

	public void setHoTen(String hoTen) {
		this.hoTen = hoTen;
	}

	public String getDt() {
		return dt;
	}

	public void setDt(String dt) {
		this.dt = dt;
	}

	public double getLuongCb() {
		return luongCb;
	}

	public void setLuongCb(float luongCb) {
		this.luongCb = luongCb;
	}
public abstract double tienLuong();

@Override
public String toString() {
	return " Mã sv:"+ MaSv + ", hoTen=" + hoTen + ", dt=" + dt + ", luongCb=" + luongCb;
}

}
