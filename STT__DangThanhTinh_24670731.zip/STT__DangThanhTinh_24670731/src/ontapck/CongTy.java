package ontapck;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CongTy {
	List<NhanVien> danhSach;

	public CongTy() {
		danhSach = new ArrayList<>();

	}

	public boolean themNhanVien(NhanVien x) {
		for (NhanVien nhanVien : danhSach) {
			if (nhanVien.getMaSv().equals(x.getMaSv())) {
				return false;
			}
		}
		danhSach.add(x);
		return true;
	}

	public double tinhTrungBinhLuong() {
		int dem = 0;
		double sum = 0;
		for (NhanVien nhanVien : danhSach) {
			if(nhanVien instanceof NhanVienBanHang) {
			sum += nhanVien.tienLuong();
			dem++;
		}
		}
		return dem==0 ? 0 :sum / dem;
	}

//Cách 1:
	public boolean xoaNhanVien(String maNV) {
		Iterator<NhanVien> it =danhSach.iterator();
		while (it.hasNext()) {
			NhanVien nv=it.next();
		
			if (nv.getMaSv().equals(maNV)) {
				it.remove();
				return true;
			}
		}
		return false;
	}
//Cách 2:
/*	public boolean xoaNhanVien(String maNV) {
		for (NhanVien nhanVien : danhSach) {
			if(nhanVien.getMaSv().equals(maNV)) {
				danhSach.remove(maNV);
				return true;
			}
		}
		return false;
	}*/
	public String xuatDSNVBanHang() {
		StringBuilder sb=new StringBuilder();
		for (NhanVien nhanVien : danhSach) {
			if(nhanVien instanceof NhanVienBanHang) {
				sb.append(nhanVien).append("\n");
			}
		}
		return sb.toString();
	}

}
