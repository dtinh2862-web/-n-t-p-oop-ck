package ontapck;

public class NhanVienHanhChinh extends NhanVien {
	private double heSoLuong;

	public NhanVienHanhChinh() {
		super();
		this.heSoLuong=1.66;
	}
	protected NhanVienHanhChinh(String maSv, String hoTen, String dt, float luongCb, double heSoLuong) {
		super(maSv, hoTen, dt, luongCb);
		setHeSoLuong(heSoLuong);
	}

	public double getHeSoLuong() {
		return heSoLuong;
	}

	public void setHeSoLuong(double heSoLuong) {
		if (heSoLuong >= 1.66 && heSoLuong <= 8.69) {
			this.heSoLuong = heSoLuong;
		} else {
			throw new RuntimeException("Lỗi");
		}
	}

	@Override
	public double tienLuong() {
		// TODO Auto-generated method stub
		return this.tienLuong()*this.heSoLuong;
	}

	@Override
	public String toString() {
		return super.toString()+", heSoLuong:" + heSoLuong + ", Tiền lương:"+tienLuong();
	}

}
