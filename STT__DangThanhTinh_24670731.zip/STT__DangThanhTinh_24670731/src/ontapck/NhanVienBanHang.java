package ontapck;

public class NhanVienBanHang extends NhanVien{


private float doanhSoBan;
public NhanVienBanHang() {
    super();
    this.doanhSoBan = 0;
}


protected NhanVienBanHang(String maSv, String hoTen, String dt, float luongCb, float doanhSoBan) {
	super(maSv, hoTen, dt, luongCb);
	setDoanhSoBan(doanhSoBan);
}



public float getDoanhSoBan() {
	return doanhSoBan;
}



public void setDoanhSoBan(float doanhSoBan) {
	if(doanhSoBan>=0) {
		this.doanhSoBan = doanhSoBan;
	}else {
		throw new RuntimeException("Doanh số bán hàng k hợp lệ!");
	}
	
}



@Override
public double tienLuong() {
	// TODO Auto-generated method stub
	if(this.doanhSoBan>=20) {
		return this.getLuongCb()+(this.doanhSoBan+this.doanhSoBan*0.3);
	}else {
		return this.getLuongCb();
	}
}



@Override
public String toString() {
	return super.toString()+", Doanh số bán:" + doanhSoBan +", Tiền lương:"+tienLuong();
}

}
