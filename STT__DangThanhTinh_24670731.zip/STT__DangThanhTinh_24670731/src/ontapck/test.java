package ontapck;

public class test {
public static void main(String[] args) {
	CongTy ct=new CongTy();
	ct.themNhanVien(new NhanVienBanHang("111", "AAA", "1234",1000 , 12));
	ct.themNhanVien(new NhanVienBanHang("112", "AAB", "1235",1001 , 14));
	ct.themNhanVien(new NhanVienBanHang("113", "AAC", "1236",1010 , 21));
	ct.themNhanVien(new NhanVienHanhChinh("114", "AAD","1237",1100, 1.78));
	ct.themNhanVien(new NhanVienHanhChinh("115", "AAE", "1238", 1101, 6.78));
System.out.println("Lương trung bình:"+ct.tinhTrungBinhLuong());
	ct.xoaNhanVien("112");
	System.out.println("\n"+ct.xuatDSNVBanHang());	
	
}
}
