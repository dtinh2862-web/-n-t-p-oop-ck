package tuan3_4_quanlychuyenxe;

public class ChuyenXeNoiThanh extends ChuyenXe {
	private int soTuyen;
	private float soKmDiDc;

	protected ChuyenXeNoiThanh(int mSoChuyen, String nameTaiXe, int soXe, float doanhThu, int soTuyen, float soKmDiDc) {
		super(mSoChuyen, nameTaiXe, soXe, doanhThu);
		this.soTuyen = soTuyen;
		this.soKmDiDc = soKmDiDc;
	}

	public int getSoTuyen() {
		return soTuyen;
	}

	public void setSoTuyen(int soTuyen) {
		this.soTuyen = soTuyen;
	}

	public float getSoKmDiDc() {
		return soKmDiDc;
	}

	public void setSoKmDiDc(float soKmDiDc) {
		this.soKmDiDc = soKmDiDc;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString()+ ", Số tuyến:" + soTuyen + ", Số km đi được:" + soKmDiDc;
	}
}
