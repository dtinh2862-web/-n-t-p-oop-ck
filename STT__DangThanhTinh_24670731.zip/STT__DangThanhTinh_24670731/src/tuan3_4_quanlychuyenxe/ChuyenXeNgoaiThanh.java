package tuan3_4_quanlychuyenxe;

public class ChuyenXeNgoaiThanh extends ChuyenXe {
	private String noiDen;
	private float soNgayDiDc;

	protected ChuyenXeNgoaiThanh(int mSoChuyen, String nameTaiXe, int soXe, float doanhThu, String noiDen,
			float soNgayDiDc) {
		super(mSoChuyen, nameTaiXe, soXe, doanhThu);
		this.noiDen = noiDen;
		this.soNgayDiDc = soNgayDiDc;
	}

	public String getNoiDen() {
		return noiDen;
	}

	public void setNoiDen(String noiDen) {
		this.noiDen = noiDen;
	}

	public float getSoNgayDiDc() {
		return soNgayDiDc;
	}

	public void setSoNgayDiDc(float soNgayDiDc) {
		this.soNgayDiDc = soNgayDiDc;
	}


	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString()+", Nới đến:" + noiDen + ", Số ngày đi được:" + soNgayDiDc;
	}
	
}
