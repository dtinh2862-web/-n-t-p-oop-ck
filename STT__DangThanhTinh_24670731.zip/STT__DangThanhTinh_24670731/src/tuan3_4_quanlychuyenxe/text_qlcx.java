package tuan3_4_quanlychuyenxe;

public class text_qlcx {
	public static void main(String[] args) {
		ChuyenXe cx[] = new ChuyenXe[5];
		
		cx[0] = new ChuyenXeNoiThanh(1, "Nguyễn Văn A", 123, 3000, 1, 300);
		cx[1] = new ChuyenXeNgoaiThanh(2, "Nguyễn Văn B", 124, 2000, "A", 3);
		cx[2] = new ChuyenXeNoiThanh(3, "Nguyễn Văn C", 125, 4000, 2, 200);
		cx[3] = new ChuyenXeNgoaiThanh(4, "Nguyễn Văn D", 126, 5000, "B", 4);
		cx[4] = new ChuyenXeNoiThanh(5, "Nguyễn Văn E", 127, 5000, 1, 300);

		for (int i = 0; i < cx.length; i++) {
			System.out.println(cx[i]);
		}
		double kq1 = 0; 
		double kq2 = 0; 

		for (int i = 0; i < cx.length; i++) {
		    if (cx[i] instanceof ChuyenXeNoiThanh) {
		        kq1 += cx[i].getDoanhThu();
		    } else {
		        kq2 += cx[i].getDoanhThu();
		    }
		}

		System.out.println("Doanh thu xe Nội thành: " + kq1);
		System.out.println("Doanh thu xe Ngoại thành: " + kq2);

		
		}

	}


