package tuan3_4_quanlychuyenxe;

public class ChuyenXe {
	private int mSoChuyen;
	private String nameTaiXe;
	private int soXe;
	private float doanhThu;

	protected ChuyenXe(int mSoChuyen, String nameTaiXe, int soXe, float doanhThu) {

		this.mSoChuyen = mSoChuyen;
		this.nameTaiXe = nameTaiXe;
		this.soXe = soXe;
		this.doanhThu = doanhThu;
	}

	public int getmSoChuyen() {
		return mSoChuyen;
	}

	public void setmSoChuyen(int mSoChuyen) {
		this.mSoChuyen = mSoChuyen;
	}

	public String getNameTaiXe() {
		return nameTaiXe;
	}

	public void setNameTaiXe(String nameTaiXe) {
		this.nameTaiXe = nameTaiXe;
	}

	public int getSoXe() {
		return soXe;
	}

	public void setSoXe(int soXe) {
		this.soXe = soXe;
	}

	public float getDoanhThu() {
		return doanhThu;
	}

	public void setDoanhThu(float doanhThu) {
		this.doanhThu = doanhThu;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Mã số chuyến:" + mSoChuyen + ", Tên tài xế:" + nameTaiXe + ", Số xe:" + soXe + ", Doanh thu:" + doanhThu;
	}
	
}
