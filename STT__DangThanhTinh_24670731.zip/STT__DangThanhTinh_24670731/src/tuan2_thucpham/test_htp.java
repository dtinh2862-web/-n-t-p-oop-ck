package tuan2_thucpham;

import java.text.ParseException;
import java.text.SimpleDateFormat;



public class test_htp {
public static void main(String[] args) throws ParseException {
	SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
	HangThucPham htp1=new HangThucPham("TP01","Bánh mì",3000,sdf.parse("12/8/2025"),sdf.parse("15/8/2025"));
	System.out.println(htp1);
	
}
}
