package tuan2_thucpham;

import java.text.SimpleDateFormat;
import java.util.Date;

public class HangThucPham {

	private String maHang, tenHang;
	private double donGia;
	private Date ngaySx, ngayHh;

	protected HangThucPham(String maHang, String tenHang, double donGia, Date ngaySx, Date ngayHh) {
		if (maHang == null || maHang.trim().equals("")) {
			System.out.println("Mã hàng k đc để trống");
			return;
		}
		if (tenHang == null || tenHang.trim().equals("")) {
			System.out.println("Tên hàng k đc để trống");
			return;
		}
		if (donGia <= 0) {
			System.out.println("Đơn giá k hợp lệ!");
			return;
		}
		if (ngaySx == null || ngayHh == null) {
			System.out.println("Ngày sx và ngày hh k đc để trống");
			return;
		}
		if (ngayHh.before(ngaySx)) {
			System.out.println("Ngày k hợp lệ!");
			return;
		}

		this.maHang = maHang;
		this.tenHang = tenHang;
		this.donGia = donGia;
		this.ngaySx = ngaySx;
		this.ngayHh = ngayHh;
	}

	protected HangThucPham(String maHang) {
		if (maHang == null || maHang.trim().equals("")) {
			System.out.println("Mã hàng k đc để trống");
			return;
		}
		// TODO Auto-generated constructor stub
	}

	public String getMaHang() {
		return maHang;
	}

	public void setMaHang(String maHang) {
		if (maHang == null || maHang.trim().equals("")) {
			System.out.println("Mã hàng k đc để trống");
		}
		this.maHang = maHang;
	}

	public String getTenHang() {
		return tenHang;
	}

	public void setTenHang(String tenHang) {
		if (tenHang == null || tenHang.trim().equals("")) {
			System.out.println("Tên hàng k đc để trống");
		}
		this.tenHang = tenHang;
	}

	public double getDonGia() {
		return donGia;
	}

	public void setDonGia(double donGia) {
		if (donGia <= 0) {
			System.out.println("Đơn giá k hợp lệ!");
		}
		this.donGia = donGia;
	}

	public Date getNgaySx() {
		return ngaySx;
	}

	public void setNgaySx(Date ngaySx) {
		this.ngaySx = ngaySx;
	}

	public Date getNgayHh() {
		return ngayHh;
	}

	public void setNgayHh(Date ngayHh) {
		if (ngayHh.before(ngaySx)) {
			System.out.println("Ngày k hợp lệ!");
		}
		this.ngayHh = ngayHh;
	}

	public boolean ktDatehh() {
		Date ngayHt = new Date();
		boolean kthh = ngayHt.after(ngayHh);
		return kthh;
	}

	public String toString() {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String donGiaStr = String.format("%,.0f VND", donGia);
		String ngaySxStr = sdf.format(ngaySx);
		String ngayHhStr = sdf.format(ngayHh);
		String tt = ktDatehh() ? "Đã hết hạn" : "Còn hạn sử dụng";
		return "Mã hàng:" + maHang + "\nTên hàng:" + tenHang + "\nĐơn giá:" + donGiaStr + "\nNgày sãn xuất:" + ngaySxStr
				+ "\nNgày hết hạn:" + ngayHhStr+"\nTrạng thái sản phẩm:"+tt;

	}

}
