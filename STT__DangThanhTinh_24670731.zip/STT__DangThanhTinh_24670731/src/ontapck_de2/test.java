package ontapck_de2;

import java.util.List;
import java.util.Map;

public class test {
	public static void main(String[] args) {
		DanhSachNhanVien ds = new DanhSachNhanVien();
		ds.themNhanVien(new NhanVienBanHang("111", "AAA", "1234", 12));
		ds.themNhanVien(new NhanVienBanHang("112", "AAB", "1235", 14));
		ds.themNhanVien(new NhanVienBanHang("113", "AAC", "1236", 21));

		ds.themNhanVien(new NhanVienVanPhong("114", "AAD", "1237", 7.78));
		ds.themNhanVien(new NhanVienVanPhong("115", "AAE", "1238", 6.78));

		System.out.println("\n=== Thống kê lương trung bình ===");
		Map<String, Double> luongTB = ds.thongKeLuongTrungBinh();
		for (String loai : luongTB.keySet()) {
			System.out.println(loai  + luongTB.get(loai));
		}
		System.out.println("=== Danh sách nhân viên bán hàng ưu tú (doanh số < 20) ===");
		List<NhanVien> uuTu = ds.getDSNhanVienUuTu();
		for (NhanVien nv : uuTu) {
			System.out.println(nv);
		}
		System.out.println("\n=== Cập nhật hệ số lương của VP01 ===");
		boolean kq = ds.capNhatNhanVien("114", 3.0);
		if (kq) {
			System.out.println("Cập nhật thành công!");
		} else {
			System.out.println("Không tìm thấy nhân viên!");
		}

		System.out.println("\n=== Danh sách sau khi cập nhật ===");
		System.out.println(ds.inDanhSach());
	}
}
