package ontapck_de2;

public class NhanVienBanHang extends NhanVien {
	private float doanhSoBanHang;

	protected NhanVienBanHang(String maSo, String hoTen, String dienThoai, float doanhSoBanHang) {
		super(maSo, hoTen, dienThoai);
		this.doanhSoBanHang = doanhSoBanHang;
	}

	public float getDoanhSoBanHang() {
		return doanhSoBanHang;
	}

	public void setDoanhSoBanHang(float doanhSoBanHang) {
		if (doanhSoBanHang >= 0) {
			this.doanhSoBanHang = doanhSoBanHang;
		} else {
			throw new RuntimeException("Lỗi");
		}

	}

	@Override
	public double tienLuong() {
		// TODO Auto-generated method stub
		if (this.doanhSoBanHang >= 20) {
			double thuNhapTangThem=0.03*this.doanhSoBanHang;
			return this.luongCanBan*thuNhapTangThem;
		} else {
			return this.luongCanBan;
		}
	}

	@Override
	public String toString() {
		return super.toString()+", doanhSoBanHang=" + doanhSoBanHang + ", getDoanhSoBanHang()=" + getDoanhSoBanHang()
				+ ", tienLuong()=" + tienLuong() ;
	}
	

}
