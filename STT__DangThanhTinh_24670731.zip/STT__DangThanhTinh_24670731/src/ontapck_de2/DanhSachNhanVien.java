package ontapck_de2;

import java.text.CollationElementIterator;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DanhSachNhanVien {
	private List<NhanVien> danhSach;

	public DanhSachNhanVien() {
		danhSach = new ArrayList<>();
	}

	public boolean themNhanVien(NhanVien nhanVien) {
		if (nhanVien == null) {
			return false;
		}
		for (NhanVien nv : danhSach) {
			if (nv.getMaSo().equals(nhanVien.getMaSo())) {
				return false;
			}
		}
		danhSach.add(nhanVien);
		return true;
	}

	public Map<String, Double> thongKeLuongTrungBinh() {
		double tongBH = 0, tongVP = 0;
		int demBH = 0, demVP = 0;
		for (NhanVien nv : danhSach) {
			if (nv instanceof NhanVienBanHang) {
				tongBH += nv.tienLuong();
				demBH++;

			}
			if (nv instanceof NhanVienVanPhong) {
				tongVP += nv.tienLuong();
				demVP++;
			}
		}
		Map<String, Double> kq = new HashMap<>();
		kq.put( "Bán Hàng:", demBH == 0 ? 0 : tongBH / demBH);
		kq.put( "Văn Phòng:",demVP == 0 ? 0 : tongVP / demVP);
		return kq;
	}

	public List<NhanVien> getDSNhanVienUuTu() {
		List<NhanVien> kq = new ArrayList<>();
		for (NhanVien nv : danhSach) {
			if (nv instanceof NhanVienBanHang) {
				NhanVienBanHang bh = (NhanVienBanHang) nv;
				if (bh.getDoanhSoBanHang() < 20) {
					kq.add(bh);
				}
			}
		}

		Collections.sort(kq, new Comparator<NhanVien>() {
			public int compare(NhanVien a, NhanVien b) {
				NhanVienBanHang bh1 = (NhanVienBanHang) a;
				NhanVienBanHang bh2 = (NhanVienBanHang) b;
				return Float.compare(bh2.getDoanhSoBanHang(), bh1.getDoanhSoBanHang());
			}

		});
		return kq;
	}

	public List<NhanVien> getDSNhanVienUuTuNhat() {
		List<NhanVien> kq = new ArrayList<>();
		float max = 0;
		for (NhanVien nv : danhSach) {
			if (nv instanceof NhanVienBanHang) {
				NhanVienBanHang bh = (NhanVienBanHang) nv;
				if (bh.getDoanhSoBanHang() > max)
					max = bh.getDoanhSoBanHang();
			}

		}

		for (NhanVien nv : danhSach) {
			if (nv instanceof NhanVienBanHang) {
				NhanVienBanHang bh = (NhanVienBanHang) nv;
				if (bh.getDoanhSoBanHang() == max)
					kq.add(bh);
			}
		}
		return kq;
	}

	public boolean capNhatNhanVien(String maSo, double heSoLuongMoi) {
		for (NhanVien nv : danhSach) {
			if (nv instanceof NhanVienVanPhong && nv.getMaSo().equals(maSo)) {
				((NhanVienVanPhong) nv).setHeSoLuong(heSoLuongMoi);
				return true;
			}
		}
		return false;
	}

	public String inDanhSach() {
		StringBuilder sb = new StringBuilder();
		for (NhanVien nhanVien : danhSach) {
			sb.append(nhanVien).append("\n");
		}
		return sb.toString();
	}

}
