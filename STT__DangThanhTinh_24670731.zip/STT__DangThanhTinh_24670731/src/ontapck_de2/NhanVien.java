package ontapck_de2;

public  abstract class NhanVien {
	protected String maSo;
	protected String hoTen;
	protected String dienThoai;
	protected final double luongCanBan = 1800000;

	protected NhanVien(String maSo, String hoTen, String dienThoai) {
		super();
		this.maSo = maSo;
		this.hoTen = hoTen;
		this.dienThoai = dienThoai;
	}

	public String getMaSo() {

		return maSo;
	}

	public void setMaSo(String maSo) {
		if (maSo != null && !maSo.isEmpty()) {
			this.maSo = maSo;
		} else {
			throw new RuntimeException("Lỗi");
		}

	}

	public String getHoTen() {
		return hoTen;
	}

	public void setHoTen(String hoTen) {
		this.hoTen = hoTen;
	}

	public String getDienThoai() {
		return dienThoai;
	}

	public void setDienThoai(String dienThoai) {
		this.dienThoai = dienThoai;
	}
   public abstract double tienLuong();

@Override
public String toString() {
	return "maSo=" + maSo + ", hoTen=" + hoTen + ", dienThoai=" + dienThoai + ", luongCanBan=" + luongCanBan
			;
}
   
}
