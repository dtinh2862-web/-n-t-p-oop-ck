package ontapck_de2;

public class NhanVienVanPhong extends NhanVien {
	private double heSoLuong;

	protected NhanVienVanPhong(String maSo, String hoTen, String dienThoai, double heSoLuong) {
		super(maSo, hoTen, dienThoai);
		this.heSoLuong = heSoLuong;
	}

	public double getHeSoLuong() {
		return heSoLuong;
	}

	public void setHeSoLuong(double heSoLuong) {
		if (heSoLuong >= 1.86 && heSoLuong <= 8.69) {
			this.heSoLuong = heSoLuong;
		} else {
			throw new RuntimeException("Giá trị k phù hợp!");
		}

	}

	@Override
	public double tienLuong() {
		// TODO Auto-generated method stub
		return this.luongCanBan*this.heSoLuong;
	}

	@Override
	public String toString() {
		return super.toString()+", heSoLuong=" + heSoLuong + ", getHeSoLuong()=" + getHeSoLuong() + ", tienLuong()="
				+ tienLuong();
	}
	
	

}