package tuan2_hinhchunhat;

public class test {
public static void main(String[] args) {
	HinhChuNhat hcn=new HinhChuNhat(6, 4);
	hcn.phepTinhHcN();
	System.out.println(hcn);
}
}
