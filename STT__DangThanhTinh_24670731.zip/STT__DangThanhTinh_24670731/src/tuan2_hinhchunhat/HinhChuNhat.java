package tuan2_hinhchunhat;

public class HinhChuNhat{
	protected double chieudai,chieurong;

	protected HinhChuNhat(double chieudai, double chieurong) {
	
		this.chieudai = chieudai;
		this.chieurong = chieurong;
	}

	public double getChieudai() {
		return chieudai;
	}

	public void setChieudai(double chieudai) {
		this.chieudai = chieudai;
	}

	public double getChieurong() {
		return chieurong;
	}

	public void setChieurong(double chieurong) {
		this.chieurong = chieurong;
	}
public void phepTinhHcN() {
	double cv=this.chieudai+chieurong;
	System.out.println("Diện tích hình chữ nhật:"+this.chieudai*chieurong);
	System.out.println("Chu vi hình chữ nhật:"+cv/2);
}

public String toString() { return "Hình Chữ Nhật "+"Chiều dài: "+this.chieudai+ 
		"Chiều rộng: "+this.chieurong ;
}

}
