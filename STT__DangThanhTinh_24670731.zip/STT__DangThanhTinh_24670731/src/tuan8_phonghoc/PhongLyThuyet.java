package tuan8_phonghoc;

public class PhongLyThuyet extends PhongHoc {
private boolean coMayChieu;

protected PhongLyThuyet(String maPH, String dayNha,float dienTich, int soBongDen, boolean coMayChieu) {
	super(maPH, dayNha ,dienTich, soBongDen);
	this.coMayChieu = coMayChieu;
}

public boolean isCoMayChieu() {
	return coMayChieu;
}

public void setCoMayChieu(boolean coMayChieu) {
	this.coMayChieu = coMayChieu;
}

@Override
public boolean datChuan() {
	return duSang()&&coMayChieu ?true:false;
}

@Override
public String toString() {
	return super.toString()+ ", coMayChieu=" + coMayChieu+", Đạt chuẩn:"+datChuan();
}


}


