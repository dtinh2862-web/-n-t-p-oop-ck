package tuan8_phonghoc;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class DanhSachPhongHoc {
	private List<PhongHoc> danhSach;

	public DanhSachPhongHoc() {
		danhSach = new ArrayList<>();
	}

	public boolean themPhong(PhongHoc p) {
		for (PhongHoc ph : danhSach) {
			if (ph.getMaPH().equals(p.getMaPH())) {
			    return false;
			}

		}
		danhSach.add(p);
		return true;
	}

	public boolean timKiem(String ma) {
		for (PhongHoc ph : danhSach) {
			if (ph.getMaPH().equals(ma)) {
				return true;
							
			}
		}
		return false;
	}
	private PhongHoc layPhongTheoMa(String ma) {
	    for (PhongHoc ph : danhSach)
	        if (ph.getMaPH().equals(ma))
	            return ph;
	    return null;
	}

	public String inDanhSach() {
	    if (danhSach.isEmpty()) {
	        return null;
	    }
	    StringBuilder sb = new StringBuilder();
	    for (PhongHoc ph : danhSach) {
	        sb.append(ph.toString()).append("\n");
	    }
	    return sb.toString();
	}

	public String inDanhSachDatChuan() {

		StringBuilder sb = new StringBuilder();// xây dựng chuỗii kết quả
		for (PhongHoc ph : danhSach) {
			if (ph.datChuan())
				sb.append(ph).append("\n");
		}
		return sb.length() == 0 ? null : sb.toString();
	}

	public void sxTheoDayNhaTang() {
		/*
		 * tạo một Comparator nhanh bằng cú pháp method reference (::). lấy giá trị dãy
		 * nhà của mỗi phòng để dùng làm tiêu chí sắp xếp.
		 */
		danhSach.sort(Comparator.comparing(PhongHoc::getDayNha));
	}

	public void sapXepTheoDienTichGiam() {
		danhSach.sort(new Comparator<PhongHoc>() {
			public int compare(PhongHoc a, PhongHoc b) {
				return Double.compare(b.getDienTich(), a.getDienTich());

			}
		});

	}

	public void sxTangTheoSoBongDen() {
		danhSach.sort(Comparator.comparing(PhongHoc::getSoBongDen));
	}

	public boolean capNhatSoMayTinh(String ma, int soMay) {
	       PhongHoc ph = layPhongTheoMa(ma);
		if (ph instanceof PhongMayTinh) {
			((PhongMayTinh) ph).setSoMayTinh(soMay);// ép kiểu(ph)-ban đầu là Phòng Học về sau là Phòng Máy Tính,rồi cập
			return true; // nhật giá trị
		}
		return false;
	}

	public boolean xoaPhong(String ma, boolean xacNhan) {
	    if (!xacNhan) return false; 

	    for (PhongHoc ph : danhSach) {
	        if (ph.getMaPH().equals(ma)) {
	            danhSach.remove(ph);
	            return true;
	        }
	    }
	    return false; 
	}

	public int tongPhongHoc() {
		return danhSach.size();
	}

	public String inDsPhong60May() {
		StringBuilder sb = new StringBuilder();
		for (PhongHoc ph : danhSach) {
			if (ph instanceof PhongMayTinh && ((PhongMayTinh) ph).getSoMayTinh() == 60) {

				sb.append(ph).append("\n");
			}
		}
		return sb.toString();
	}
}
