
package tuan8_phonghoc;

import java.util.Scanner;

public class test {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DanhSachPhongHoc ds = new DanhSachPhongHoc();
        int chon;

        do {
            System.out.println("\n===== MENU QUẢN LÝ PHÒNG HỌC =====");
            System.out.println("1. Thêm phòng học");
            System.out.println("2. Tìm phòng học theo mã");
            System.out.println("3. In danh sách tất cả phòng học");
            System.out.println("4. In danh sách phòng đạt chuẩn");
            System.out.println("5. Sắp xếp theo dãy nhà tăng dần");
            System.out.println("6. Sắp xếp theo diện tích giảm dần");
            System.out.println("7. Sắp xếp theo số bóng đèn tăng dần");
            System.out.println("8. Cập nhật số máy tính cho phòng máy");
            System.out.println("9. Xóa phòng học theo mã");
            System.out.println("10. In tổng số phòng học");
            System.out.println("11. In danh sách phòng máy có 60 máy");
            System.out.println("0. Thoát chương trình");
            System.out.print("Nhập lựa chọn của bạn: ");
            
            // kiểm tra nhập sai kiểu dữ liệu
            while (!sc.hasNextInt()) {
                System.out.println("Lựa chọn phải là số! Vui lòng nhập lại: ");
                sc.next();
            }
            chon = sc.nextInt();
            sc.nextLine();

            switch (chon) {
                case 1: {
                    int loai;
                    do {
                        System.out.println("\nChọn loại phòng để thêm:");
                        System.out.println("1. Phòng lý thuyết");
                        System.out.println("2. Phòng máy tính");
                        System.out.println("3. Phòng thí nghiệm");
                        System.out.print("Nhập lựa chọn: ");

                        while (!sc.hasNextInt()) {
                            System.out.println("Vui lòng nhập số 1, 2 hoặc 3!");
                            sc.next();
                        }
                        loai = sc.nextInt();
                        sc.nextLine();

                        if (loai < 1 || loai > 3) {
                            System.out.println("Lựa chọn không hợp lệ! Vui lòng nhập lại.\n");
                        }
                    } while (loai < 1 || loai > 3);

                    System.out.print("Nhập mã phòng: ");
                    String ma = sc.nextLine();
                    System.out.print("Nhập dãy nhà: ");
                    String dayNha = sc.nextLine();
                    System.out.print("Nhập diện tích: ");
                    double dienTich = sc.nextDouble();
                    System.out.print("Nhập số bóng đèn: ");
                    int soBong = sc.nextInt();
                    sc.nextLine();

                    PhongHoc ph = null;

                    if (loai == 1) { 
                        System.out.print("Nhập có máy chiếu (true/false): ");
                        boolean mayChieu = sc.nextBoolean();
                        ph = new PhongLyThuyet(ma, dayNha, loai, soBong, mayChieu);
                    } else if (loai == 2) { 
                        System.out.print("Nhập số máy tính: ");
                        int soMay = sc.nextInt();
                        ph = new PhongMayTinh(ma, dayNha, loai, soBong, soMay);
                    } else { 
                        sc.nextLine();
                        System.out.print("Nhập chuyên ngành: ");
                        String cn = sc.nextLine();
                        System.out.print("Nhập sức chứa: ");
                        int sucChua = sc.nextInt();
                        System.out.print("Nhập có bồn rửa (true/false): ");
                        boolean bonRua = sc.nextBoolean();
                        ph = new PhongThiNghiem(ma, dayNha, loai, soBong, cn, sucChua, bonRua);
                    }

                    boolean kqThem = ds.themPhong(ph);
                    if (kqThem)
                        System.out.println("Thêm phòng thành công!");
                    else
                        System.out.println(" Mã phòng bị trùng, không thể thêm.");
                    break;
                }

                case 2: {
                    System.out.print("Nhập mã phòng cần tìm: ");
                    String maTim = sc.nextLine();
                    boolean tonTai = ds.timKiem(maTim);
                    if (tonTai)
                        System.out.println("Phòng học có mã " + maTim + " tồn tại trong danh sách.");
                    else
                        System.out.println(" Không tìm thấy phòng học có mã " + maTim);
                    break;
                }

                case 3: {
                    String dsAll = ds.inDanhSach();
                    if (dsAll == null)
                        System.out.println(" Danh sách trống!");
                    else
                        System.out.println(dsAll);
                    break;
                }

                case 4: {
                    String dsDatChuan = ds.inDanhSachDatChuan();
                    if (dsDatChuan == null)
                        System.out.println("Không có phòng đạt chuẩn.");
                    else
                        System.out.println(dsDatChuan);
                    break;
                }

                case 5:
                    ds.sxTheoDayNhaTang();
                    System.out.println("Đã sắp xếp theo dãy nhà tăng dần.");
                    break;

                case 6:
                    ds.sapXepTheoDienTichGiam();
                    System.out.println("Đã sắp xếp theo diện tích giảm dần.");
                    break;

                case 7:
                    ds.sxTangTheoSoBongDen();
                    System.out.println("Đã sắp xếp theo số bóng đèn tăng dần.");
                    break;

                case 8: {
                    System.out.print("Nhập mã phòng máy cần cập nhật: ");
                    String maCN = sc.nextLine();
                    System.out.print("Nhập số máy mới: ");
                    int soMay = sc.nextInt();
                    boolean capNhat = ds.capNhatSoMayTinh(maCN, soMay);
                    if (capNhat)
                        System.out.println("Cập nhật thành công!");
                    else
                        System.out.println("Không cập nhật được (không phải phòng máy hoặc mã sai).");
                    break;
                }

                case 9: {
                    System.out.print("Nhập mã phòng cần xóa: ");
                    String maXoa = sc.nextLine();
                    System.out.print("Bạn có chắc muốn xóa? (true/false): ");
                    boolean xacNhan = sc.nextBoolean();
                    boolean xoaOK = ds.xoaPhong(maXoa, xacNhan);
                    if (xoaOK)
                        System.out.println("Xóa thành công!");
                    else
                        System.out.println("Không tìm thấy hoặc không xác nhận xóa.");
                    break;
                }

                case 10:
                    System.out.println("Tổng số phòng học: " + ds.tongPhongHoc());
                    break;

                case 11: {
                    String ds60 = ds.inDsPhong60May();
                    if (ds60 == null || ds60.isEmpty())
                        System.out.println("Không có phòng nào có đúng 60 máy.");
                    else
                        System.out.println(ds60);
                    break;
                }

                case 0:
                    System.out.println("Thoát chương trình!");
                    break;

                default:
                    System.out.println("Lựa chọn không hợp lệ! Vui lòng nhập từ 0–11.");
                    break;
            }

        } while (chon != 0);

        sc.close();
    }
}

