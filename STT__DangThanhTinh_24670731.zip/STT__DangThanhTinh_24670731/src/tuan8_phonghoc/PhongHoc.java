package tuan8_phonghoc;

public abstract class PhongHoc {
private String maPH;
private String dayNha;
private float dienTich;
private int soBongDen;
protected PhongHoc(String maPH, String dayNha, float dienTich, int soBongDen) {
	super();
	this.maPH = maPH;
	this.dayNha = dayNha;
	this.dienTich = dienTich;
	this.soBongDen = soBongDen;
}
public String getMaPH() {
	return maPH;
}
public void setMaPH(String maPH) {
	this.maPH = maPH;
}
public String getDayNha() {
	return dayNha;
}
public void setDayNha(String dayNha) {
	this.dayNha = dayNha;
}
public float getDienTich() {
	return dienTich;
}
public void setDienTich(float dienTich) {
	this.dienTich = dienTich;
}
public int getSoBongDen() {
	return soBongDen;
}
public void setSoBongDen(int soBongDen) {
	this.soBongDen = soBongDen;
}
public  abstract boolean datChuan();
public boolean duSang() {
	return dienTich>=10 && soBongDen>=1 ? true:false;
}
@Override
public String toString() {
	return "maPH=" + maPH + ", dayNha=" + dayNha + ", dienTich=" + dienTich + ", soBongDen=" + soBongDen
			;
}

}
