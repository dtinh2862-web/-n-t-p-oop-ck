package tuan8_phonghoc;

public class PhongThiNghiem extends PhongHoc{
private String chuyenNganh;
private int sucChua;
private boolean bonRuaChen;
protected PhongThiNghiem(String maPH, String dayNha, float dienTich, int soBongDen, String chuyenNganh, int sucChua,
		boolean bonRuaChen) {
	super(maPH, dayNha, dienTich, soBongDen);
	this.chuyenNganh = chuyenNganh;
	this.sucChua = sucChua;
	this.bonRuaChen = bonRuaChen;
}
public String getChuyenNganh() {
	return chuyenNganh;
}
public void setChuyenNganh(String chuyenNganh) {
	this.chuyenNganh = chuyenNganh;
}
public int getSucChua() {
	return sucChua;
}
public void setSucChua(int sucChua) {
	this.sucChua = sucChua;
}
public boolean isBonRuaChen() {
	return bonRuaChen;
}
public void setBonRuaChen(boolean bonRuaChen) {
	this.bonRuaChen = bonRuaChen;
}
@Override
public boolean datChuan() {
	// TODO Auto-generated method stub
	return duSang() && bonRuaChen ? true:false;
}
@Override
public String toString() {
	return super.toString()+"chuyenNganh=" + chuyenNganh + ", sucChua=" + sucChua + ", bonRuaChen=" + bonRuaChen +", Đạt chuẩn:"+datChuan();
}

}
