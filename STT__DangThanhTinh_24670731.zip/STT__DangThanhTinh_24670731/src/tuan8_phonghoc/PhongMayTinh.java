package tuan8_phonghoc;

public class PhongMayTinh extends PhongHoc {
private int soMayTinh;

protected PhongMayTinh(String maPH, String dayNha, float dienTich, int soBongDen, int soMayTinh) {
	super(maPH, dayNha, dienTich, soBongDen);
	this.soMayTinh = soMayTinh;
}

public int getSoMayTinh() {
	return soMayTinh;
}

public void setSoMayTinh(int soMayTinh) {
	this.soMayTinh = soMayTinh;
}

@Override
public boolean datChuan() {
	// TODO Auto-generated method stub
	return duSang() &&(getDienTich()>=1.5 &&soMayTinh>=1) ? true:false;

}

@Override
public String toString() {
	return super.toString()+", soMayTinh=" + soMayTinh +"Đạt chuẩn:"+datChuan();
}

}