package tuan3_4_qlsach;

public  class  SachThamKhao extends Sach {
	private float thue;

	protected SachThamKhao(String maSach, String ngayNhap, float donGia, int soLuong, String nXB, float thue) {
		super(maSach, ngayNhap, donGia, soLuong, nXB);
		this.thue = thue;
	}

	public float getThue() {
		return thue;
	}

	public void setThue(float thue) {
		this.thue = thue;
	}

	public double giaSach() {
		return this.getSoLuong() * this.getDonGia() + this.thue;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString() + "Thuế:" + thue + ", Giá sách TK:" + giaSach();
	}


	
}
