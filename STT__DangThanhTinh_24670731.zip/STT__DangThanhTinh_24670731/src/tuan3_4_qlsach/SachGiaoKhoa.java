package tuan3_4_qlsach;

public  class SachGiaoKhoa extends Sach {

	private tinhtrang tinhTrang;

	protected SachGiaoKhoa(String maSach, String ngayNhap, float donGia, int soLuong, String nXB, tinhtrang tinhTrang) {
		super(maSach, ngayNhap, donGia, soLuong, nXB);
		this.tinhTrang = tinhTrang;
	}

	public tinhtrang getTinhTrang() {
		return tinhTrang;
	}

	public void setTinhTrang(tinhtrang tinhTrang) {
		this.tinhTrang = tinhTrang;
	}

	public double giaSach() {
		if (this.tinhTrang == tinhtrang.moi) {
			return this.getSoLuong() * this.getDonGia();
		} else {
			return this.getSoLuong() * this.getDonGia() * 0.5;
		}

	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString() + ",Tình trạng:" + this.tinhTrang + ", Giá SGK:" + giaSach();
	}

	
	
	
	
}
