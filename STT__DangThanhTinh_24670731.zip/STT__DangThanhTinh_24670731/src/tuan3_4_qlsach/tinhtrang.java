package tuan3_4_qlsach;

public enum tinhtrang {
moi,cu;
}
