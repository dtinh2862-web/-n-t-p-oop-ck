package tuan3_4_qlsach;

public class test_sach {
	public static void main(String[] args) {
		Sach s[] = new Sach[4];
		s[0] = new SachGiaoKhoa("MS1", "22-2-2001", 2000, 10, "X", tinhtrang.cu);
		s[1] = new SachThamKhao("MS2", "11-4-2000", 5000, 20, "Nguyễn Văn B", 100);
		s[2] = new SachGiaoKhoa("MS3", "2-2-2006", 3000, 10, "Nguyễn Văn C", tinhtrang.moi);
		s[3] = new SachThamKhao("MS4", "19-7-2010", 8000, 20, "Nguyễn Văn D", 300);
		for (int i = 0; i < s.length; i++) {
			System.out.println(s[i]);
		}
		double tongTienSGK = 0;

		for (int i = 0; i < s.length; i++) {
			if (s[i] instanceof SachGiaoKhoa) {
				tongTienSGK += s[i].giaSach();

			}

		}
		double tongTienSTK = 0;
		for (int i = 0; i < s.length; i++) {
			if (s[i] instanceof SachThamKhao) {
				tongTienSTK += s[i].giaSach();
			}
		}
		System.out.println("Tổng tiền SGK:" + tongTienSGK);
		System.out.println("Tổng tiền STK:" + tongTienSTK);
		int dem = 0;
		for (int i = 0; i < s.length; i++) {
			if (s[i] instanceof SachThamKhao) {
				dem++;

			}
		}
		System.out.println("Trung bình cộng STK:" + tongTienSTK / dem);
		for (int i = 0; i < s.length; i++) {
			if (s[i] instanceof SachGiaoKhoa) {
				SachGiaoKhoa sgk = (SachGiaoKhoa) s[i];
				if (sgk.getNXB().equals("X")) {
					System.out.println("SGK của NXB 'X'" + sgk);
				}
			}
		}
	}
}
