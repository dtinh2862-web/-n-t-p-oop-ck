package tuan2_xe;

public class test_xe {
public static void main(String[] args) {
	Vehicle xe1= new Vehicle("Đặng Thành Tính","Xe đạp", 100, 8000000);
	Vehicle xe2= new Vehicle("Nguyễn Văn A","Ô tô", 600, 800000000);
	Vehicle xe3= new Vehicle("Trần Minh B","Xe máy", 300, 80000000);
	
	System.out.printf("%-20s %-15s %-10s %-15s %-15s\n",
            "Tên chủ xe", "Loại xe", "Dung tích", "Trị giá", "Thuế phải nộp");
    System.out.println("======================================================================");
    System.out.println(xe1);
	System.out.println(xe2);
	System.out.println(xe3);
}
}
