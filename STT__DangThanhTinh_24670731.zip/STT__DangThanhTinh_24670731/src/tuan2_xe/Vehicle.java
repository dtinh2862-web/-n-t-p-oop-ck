package tuan2_xe;

public class Vehicle {
protected String hoTen;
protected String LoaiXe;
protected int dungTich;
protected double triGia;
protected Vehicle(String hoTen, String loaiXe, int dungTich, double triGia) {
	
	this.hoTen = hoTen;
	LoaiXe = loaiXe;
	this.dungTich = dungTich;
	this.triGia = triGia;
}
public String getHoTen() {
	return hoTen;
}
public void setHoTen(String hoTen) {
	this.hoTen = hoTen;
}
public String getLoaiXe() {
	return LoaiXe;
}
public void setLoaiXe(String loaiXe) {
	LoaiXe = loaiXe;
}
public int getDungTich() {
	return dungTich;
}
public void setDungTich(int dungTich) {
	this.dungTich = dungTich;
}
public double getTriGia() {
	return triGia;
}
public void setTriGia(double triGia) {
	this.triGia = triGia;
}
public double thuePhaiNop() {
	double thuenop;
	if(this.dungTich<100) {
		return this.triGia*0.01;
	}else if(this.dungTich>=100 && this.dungTich>200) {
		return this.triGia*0.03;
	}else {
		return this.triGia*0.05;
	}
}
@Override

public String toString() {
    return String.format("%-20s %-15s %-10d %-15.2f %-15.2f",
            hoTen, LoaiXe, dungTich, triGia, thuePhaiNop());
}


}
