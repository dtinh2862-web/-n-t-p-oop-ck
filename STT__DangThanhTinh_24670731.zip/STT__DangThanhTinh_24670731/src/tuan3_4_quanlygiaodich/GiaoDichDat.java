package tuan3_4_quanlygiaodich;

import java.time.LocalDate;

public class GiaoDichDat extends GiaoDich {
	private loaidat loaiDat;

	protected GiaoDichDat(String maGiaoDich, LocalDate ngayGiao, float donGia, float dienTich, loaidat loaiDat) {
		super(maGiaoDich, ngayGiao, donGia, dienTich);
		// TODO Auto-generated constructor stub
		this.loaiDat=loaiDat;
	}

	public loaidat getLoaiDat() {
		return loaiDat;
	}

	public void setLoaiDat(loaidat loaiDat) {
		this.loaiDat = loaiDat;
	}

	@Override
	public double tinhThanhTien() {
		if (this.loaiDat == loaidat.B) {
			return this.getDienTich() * this.getDonGia();
		} else if (this.loaiDat == loaidat.C) {
			return this.getDienTich() * this.getDonGia();
		} else  {
			return this.getDienTich() * this.getDonGia() * 1.5;
		}

	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString() + ", Loại đất: " + loaiDat + ", Thành tiền: " + tinhThanhTien();
	}
}
