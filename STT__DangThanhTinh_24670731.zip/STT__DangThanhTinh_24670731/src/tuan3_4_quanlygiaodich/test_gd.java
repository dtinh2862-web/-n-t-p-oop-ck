package tuan3_4_quanlygiaodich;

import java.time.LocalDate;

public class test_gd {
	private static boolean GiaoDichDat;

	public static void main(String[] args) {
		GiaoDich lst[] = new GiaoDich[5];
		lst[0] = new GiaoDichNha("111", LocalDate.now(), 3000, 70, loainha.Thuong, "TPHCM");
		lst[1] = new GiaoDichDat("222", LocalDate.now(), 4000, 80, loaidat.B);
		lst[2] = new GiaoDichDat("333", LocalDate.now(), 5000, 90, loaidat.A);
		lst[3] = new GiaoDichDat("444", LocalDate.now(), 6000, 60, loaidat.C);
		lst[4] = new GiaoDichNha("555", LocalDate.now(), 7000, 500, loainha.Caocap, "TPHCM");
		System.out.println("DANH SÁCH GIAO DỊCH");
		int slD = 0, slN = 0;

		for (int i = 0; i < lst.length; i++) {
			if (lst[i] instanceof GiaoDichDat) {
				slD++;
			} else if (lst[i] instanceof GiaoDichNha) {
				slN++;
			}
		}

		System.out.println("Tổng số giao dịch đất: " + slD);
		System.out.println("Tổng số giao dịch nhà: " + slN);

		double tongTienDat=0;
		int dem=0;
		for(int i=0;i<lst.length;i++) {
			if( lst[i] instanceof GiaoDichDat) {
				tongTienDat+=lst[i].tinhThanhTien();
				dem++;
				
			}
		}
		double tbTienDat;
		if(dem>0) {
			tbTienDat=tongTienDat/dem;
		}else {
			tbTienDat=0;
		}
		System.out.println("Tổng trung bình tiền giao dichj đất:"+tbTienDat);
	}
}
