package tuan3_4_quanlygiaodich;

import java.time.LocalDate;

public abstract class GiaoDich {
	private String maGiaoDich;
	private LocalDate ngayGiao;
	private float donGia;
	private float dienTich;

	protected GiaoDich(String maGiaoDich, LocalDate ngayGiao, float donGia, float dienTich) {

		this.maGiaoDich = maGiaoDich;
		this.ngayGiao = ngayGiao;
		this.donGia = donGia;
		this.dienTich = dienTich;
	}

	public String getMaGiaoDich() {
		return maGiaoDich;
	}

	public void setMaGiaoDich(String maGiaoDich) {
		this.maGiaoDich = maGiaoDich;
	}

	public LocalDate getNgayGiao() {
		return ngayGiao;
	}

	public void setNgayGiao(LocalDate ngayGiao) {
		this.ngayGiao = ngayGiao;
	}

	public float getDonGia() {
		return donGia;
	}

	public void setDonGia(float donGia) {
		this.donGia = donGia;
	}

	public float getDienTich() {
		if (dienTich > 0) {
			this.dienTich = dienTich;
		} else {
			throw new RuntimeException("Dien tich phai >0");
		}
		return dienTich;
	}

	public void setDienTich(float dienTich) {
		this.dienTich = dienTich;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Mã GD:" + maGiaoDich + ", Ngày giao dịch" + ngayGiao + " , Đơn giá: " + donGia + ", Diện tích: "
				+ dienTich;
	}

	public abstract double tinhThanhTien();
}
