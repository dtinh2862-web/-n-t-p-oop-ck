package tuan3_4_quanlygiaodich;

public enum loainha {
Thuong,Caocap;
}
