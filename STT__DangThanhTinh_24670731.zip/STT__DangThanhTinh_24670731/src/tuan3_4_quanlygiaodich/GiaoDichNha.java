package tuan3_4_quanlygiaodich;

import java.time.LocalDate;

public class GiaoDichNha extends GiaoDich {
	private loainha loaiNha;
	private String diaChi;

	public GiaoDichNha(String maGiaoDich, LocalDate ngayGiao, float donGia, float dienTich, loainha loaiNha,
			String diaChi) {
		super(maGiaoDich, ngayGiao, donGia, dienTich);
		this.loaiNha = loaiNha;
		this.diaChi = diaChi;
	}

	public loainha getLoaiNha() {
		return loaiNha;
	}

	public void setLoaiNha(loainha loaiNha) {
		this.loaiNha = loaiNha;
	}

	@Override
	public double tinhThanhTien() {
		if (this.loaiNha == loainha.Caocap) {
			return this.getDienTich() * this.getDonGia();
		} else {
			return this.getDienTich() * this.getDonGia() * 0.9;
		}
	}

	@Override
	public String toString() {
		return super.toString() + ", Loại nhà: " + loaiNha + ", Địa chỉ: " + diaChi + ", Thành tiền: "
				+ tinhThanhTien();
	}
}
