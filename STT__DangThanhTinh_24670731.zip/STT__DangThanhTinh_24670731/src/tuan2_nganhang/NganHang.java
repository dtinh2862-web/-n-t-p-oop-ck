package tuan2_nganhang;

public class NganHang {
	private long stk;
	private String tenTK;
	private double soTienTrongTk;
	private static final double LAISUAT = 0.035;

	protected NganHang(long stk, String tenTK, double soTienTrongTk) {

		this.stk = stk;
		this.tenTK = tenTK;
		this.soTienTrongTk = soTienTrongTk;
	}

	protected NganHang(long stk, String tenTK) {

		this.stk = stk;
		this.tenTK = tenTK;
		this.soTienTrongTk = 50;
	}

	public long getStk() {
		return stk;
	}

	public void setStk(long stk) {
		this.stk = stk;
	}

	public String getTenTK() {
		return tenTK;
	}

	public void setTenTK(String tenTK) {
		this.tenTK = tenTK;
	}

	public double getSoTienTrongTk() {
		return soTienTrongTk;
	}

	public void setSoTienTrongTk(double soTienTrongTk) {
		this.soTienTrongTk = soTienTrongTk;
	}

	public void nhapTien(int n) {
		if (n > 0) {
			this.soTienTrongTk += n;
		} else {
			System.out.println("Số tiền nhập vào k hợp lệ!");
		}

	}

	public void rutTien(int soTien, int phiRut) {
		if (soTien > 0) {
			this.soTienTrongTk -= (soTien + phiRut);
		} else {
			System.out.println("Số tiền rút k hợp lệ!");
		}
	}

	public String toString() {
		return String.format("%-20s %-15d %-10.2f ", tenTK, stk, soTienTrongTk);
	}

	public void daoHan() {
		this.soTienTrongTk = this.soTienTrongTk + this.soTienTrongTk * LAISUAT;
	}

	public void chuyenKhoan(NganHang tkNhan, int soTien) {
		if (soTien > 0 && this.soTienTrongTk >= soTien) {
			this.soTienTrongTk -= soTien;
			tkNhan.soTienTrongTk += soTien;
		} else {
			System.out.println("Số tiền chuyển k hợp lệ!");
		}
	}

}
