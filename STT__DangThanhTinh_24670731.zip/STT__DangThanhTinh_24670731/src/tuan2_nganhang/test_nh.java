package tuan2_nganhang;

public class test_nh {
public static void main(String[] args) {
	NganHang n1=new NganHang(1234, "Đặng Thành Tính", 1000000);
	NganHang n2=new NganHang(1235, "Nguyễn Văn A", 2000000);
	 System.out.printf("%-20s %-15s %-20s\n", "Tên TK", "STK", "Số tiền trong tài khoản");
	 n1.nhapTien(1000);
	 n2.rutTien(2000, 10);
	 n1.daoHan();
	 n2.daoHan();
	 n1.chuyenKhoan(n2, 5000);
	System.out.println(n1);
	System.out.println(n2);
	
}
}
