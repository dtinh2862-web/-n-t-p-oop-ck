package tuan2_sinhvien;

public class test_sv {
public static void main(String[] args) {
	QLSV ql3=new QLSV();
	System.out.println(ql3);
	QLSV ql1=new QLSV(111,"Dang Thanh Tinh",8,8);
	System.out.println(ql1);
	
}
}
