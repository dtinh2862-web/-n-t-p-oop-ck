package tuan2_sinhvien;

public class QLSV {
private int MSV;
private String HoTen;
private float diemLT,diemTH;
private String M;
public QLSV() {
	this.MSV=0;
	this.HoTen="";
	this.diemLT=0.0f;
	this.diemTH=0.0f;
}
protected QLSV(int mSV, String hoTen, float diemLT, float diemTH) {

	MSV = mSV;
	HoTen = hoTen;
	this.diemLT = diemLT;
	this.diemTH = diemTH;
}
public int getMSV() {
	return MSV;
}
public void setMSV(int mSV) {
	MSV = mSV;
}
public String getHoTen() {
	return HoTen;
}
public void setHoTen(String hoTen) {
	HoTen = hoTen;
}
public float getDiemLT() {
	return diemLT;
}
public void setDiemLT(float diemLT) {
	this.diemLT = diemLT;
}
public float getDiemTH() {
	return diemTH;
}
public void setDiemTH(float diemTH) {
	this.diemTH = diemTH;
}
public double diemTB() {
	return (this.diemLT+this.diemTH)/2;
	
}


public String toString() {
    return "Mã SV: " + this.MSV +
           ", Họ tên: " + this.HoTen +
           ", Điểm LT: " + this.diemLT +
           ", Điểm TH: " + this.diemTH +
           ", Điểm TB: " + diemTB();
}



}
