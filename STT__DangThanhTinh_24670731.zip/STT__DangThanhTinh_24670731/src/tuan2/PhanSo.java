package tuan2;

public class PhanSo {
	private int tuso, mauso;

	protected PhanSo(int tuso, int mauso) {

		this.tuso = tuso;
		this.mauso = mauso;

	}

	public int getTuso() {
		return tuso;
	}

	public void setTuso(int tuso) {
		this.tuso = tuso;
	}

	public int getMauso() {
		return mauso;
	}

	public void setMauso(int mauso) {
		this.mauso = mauso;

	}

	public int Uscln(int a, int b) {
		while (b != 0) {
			int tmp = a % b;

			a = b;
			b = tmp;
		}
		return a;
	}

	public void toiGianPs() {

		int uscln = Uscln(tuso, mauso);
		this.tuso = this.tuso / uscln;
		this.mauso = this.mauso / uscln;
		if (mauso < 0) {
			tuso = -tuso;
			mauso = -mauso;
		}
	}

	public PhanSo nghichDaoPs() {
		return new PhanSo(mauso, tuso);
	}

	public PhanSo cong(PhanSo ps) {
		int tu = this.tuso * ps.mauso + ps.tuso * this.mauso;
		int mau = this.mauso * ps.mauso;
		PhanSo kq = new PhanSo(tu, mau);
		kq.toiGianPs();
		return kq;
	}

	public PhanSo tru(PhanSo ps) {
		int tu = this.tuso * ps.mauso - ps.tuso * this.mauso;
		int mau = this.mauso * ps.mauso;
		PhanSo kq = new PhanSo(tu, mau);
		kq.toiGianPs();
		return kq;
	}

	public PhanSo nhan(PhanSo ps) {
		int tu = this.tuso * ps.tuso;
		int mau = this.mauso * ps.mauso;
		PhanSo kq = new PhanSo(tu, mau);
		kq.toiGianPs();
		return kq;
	}

	public PhanSo chia(PhanSo ps) {
		int tu = this.tuso * ps.mauso;
		int mau = this.mauso * ps.tuso;
		PhanSo kq = new PhanSo(tu, mau);
		kq.toiGianPs();
		return kq;
	}

	public int sosanh(PhanSo ps) {
		int kt1 = this.tuso * ps.mauso;
		int kt2 = ps.tuso * this.mauso;
		if (kt1 > kt2) {
			return 1;
		} else if (kt1 < kt2) {
			return -1;
		} else {
			return 0;
		}
	}

	public String toString() {

		if (this.mauso == 1)
			return String.valueOf(tuso);
		return tuso + "/" + mauso;
	}
}
