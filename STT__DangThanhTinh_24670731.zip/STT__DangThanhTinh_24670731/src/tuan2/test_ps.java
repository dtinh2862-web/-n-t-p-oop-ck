package tuan2;

public class test_ps {
	public static void main(String[] args) {
		PhanSo ps1 = new PhanSo(2, 3);
		PhanSo ps2 = new PhanSo(4, 3);
		ps1.toiGianPs();
		ps2.toiGianPs();
		System.out.println(ps1);
		// System.out.println("Phân số nghịch đảo:"+ps2.nghichDaoPs());

		System.out.println("Cộng phân số:" + ps1.cong(ps2));
		System.out.println("Trừ phân số:" + ps2.tru(ps1));
		System.out.println("Nhân phân số:" + ps1.nhan(ps2));
		System.out.println("Chia phân số:" + ps1.chia(ps2));
		System.out.println("So sánh ps1 vs ps2:" + ps2.sosanh(ps1));
	}
}
